from SECRET import flag


diction = {     
                "'" : '.--',
                'Y' : '--.',
                'C' : '..-',
                'O' : '---',
                '_' : '----',
                '1' : '--..',
                'u' : '-...',
                'o' : '--',
                '{' : '.---',
                'n' : '---.',
                'B' : '...',
                'v' : '-..',
                '}' : '-.',
                'd' : '.',
                'e' : '-',
                'F' : '...-',
                'r' : '..--',
                'T' : '..',
                'E' : '.-'
          }


i = 0
while i < len(flag):
    flag = flag[:i] + flag[i + 1] + flag[i] + flag[i + 2:]
    i += 2

for i in flag:
    print(diction[i], end=' ')