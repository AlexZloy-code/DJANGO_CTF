from SECRET import flag
from random import random_num as r_num


matrix = [list(flag[i:i + 5]) for i in range(0, len(flag), 5)]

flag = ''

for i in range(len(matrix[0])):
    for j in range(len(matrix)):
        flag += matrix[j][i]

flag = ''.join([chr(sum([ord(i) + r_num() for _ in range(11)])) for i in flag])
print(flag)